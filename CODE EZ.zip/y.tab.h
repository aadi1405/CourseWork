/* A Bison parser, made by GNU Bison 3.5.1.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2020 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Undocumented macros, especially those whose name start with YY_,
   are private implementation details.  Do not rely on them.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    NUMBER = 258,
    ENCRYPT = 259,
    EQ = 260,
    DECRYPT = 261,
    LCB = 262,
    RCB = 263,
    PROC = 264,
    MAIN = 265,
    METHODNAME = 266,
    BGIN = 267,
    COLON = 268,
    END = 269,
    ASSIGNMENT = 270,
    VAR_START = 271,
    COMA = 272,
    SEMICOLON = 273,
    EOS = 274,
    VAR = 275,
    TYP = 276,
    LB = 277,
    RB = 278,
    WRITE = 279,
    QUOTED_STRING = 280,
    IF = 281,
    OTHER = 282,
    ENDIF = 283,
    GEQ = 284,
    LEQ = 285,
    GT = 286,
    LT = 287,
    NEQ = 288,
    DEQ = 289,
    NOT = 290,
    LAND = 291,
    LOR = 292,
    GOTO = 293,
    ORELSE = 294,
    FOR = 295,
    TO = 296,
    DO = 297,
    ENDFOR = 298,
    ARROW_ASSIGNMENT = 299,
    PLUS = 300,
    MINUS = 301,
    MUL = 302,
    BOX = 303,
    IN = 304,
    DIV = 305,
    MOD = 306,
    REPEAT = 307,
    UNTIL = 308,
    WHILE = 309,
    ENDWHILE = 310,
    COMMENT = 311,
    SL = 312,
    SR = 313,
    CMP = 314,
    EXPO = 315,
    REV = 316,
    VAL = 317,
    CREATE = 318,
    ELSE = 319,
    ELSEIF = 320,
    BOXNUMBER = 321,
    XOR = 322,
    ONE = 323,
    INT = 324,
    CHAR = 325,
    FLOAT = 326,
    DOUBLE = 327,
    STRING = 328
  };
#endif
/* Tokens.  */
#define NUMBER 258
#define ENCRYPT 259
#define EQ 260
#define DECRYPT 261
#define LCB 262
#define RCB 263
#define PROC 264
#define MAIN 265
#define METHODNAME 266
#define BGIN 267
#define COLON 268
#define END 269
#define ASSIGNMENT 270
#define VAR_START 271
#define COMA 272
#define SEMICOLON 273
#define EOS 274
#define VAR 275
#define TYP 276
#define LB 277
#define RB 278
#define WRITE 279
#define QUOTED_STRING 280
#define IF 281
#define OTHER 282
#define ENDIF 283
#define GEQ 284
#define LEQ 285
#define GT 286
#define LT 287
#define NEQ 288
#define DEQ 289
#define NOT 290
#define LAND 291
#define LOR 292
#define GOTO 293
#define ORELSE 294
#define FOR 295
#define TO 296
#define DO 297
#define ENDFOR 298
#define ARROW_ASSIGNMENT 299
#define PLUS 300
#define MINUS 301
#define MUL 302
#define BOX 303
#define IN 304
#define DIV 305
#define MOD 306
#define REPEAT 307
#define UNTIL 308
#define WHILE 309
#define ENDWHILE 310
#define COMMENT 311
#define SL 312
#define SR 313
#define CMP 314
#define EXPO 315
#define REV 316
#define VAL 317
#define CREATE 318
#define ELSE 319
#define ELSEIF 320
#define BOXNUMBER 321
#define XOR 322
#define ONE 323
#define INT 324
#define CHAR 325
#define FLOAT 326
#define DOUBLE 327
#define STRING 328

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 23 "parserfinal.y"

int data_type;
char var_name[30];

#line 208 "y.tab.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
